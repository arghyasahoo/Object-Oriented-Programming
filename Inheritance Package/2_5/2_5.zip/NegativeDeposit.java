package com.oopslab.assignment;

public class NegativeDeposit extends NegativeAmount {
    public NegativeDeposit(String message) {
        super(message);
    }
}
