package com.oopslab.assignment;

public class NegativeBalance extends NegativeAmount {
    public NegativeBalance(String message) {
        super(message);
    }
}
