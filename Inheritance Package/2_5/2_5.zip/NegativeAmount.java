package com.oopslab.assignment;

public class NegativeAmount extends Exception {
    public NegativeAmount(String message) {
        super(message);
    }
}
