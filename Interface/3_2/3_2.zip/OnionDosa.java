public class OnionDosa implements Dosa {
	@Override
	public void decoration() {
		System.out.println("Decorated with Onion Scrap");
	}
}