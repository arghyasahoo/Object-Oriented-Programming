public interface Dosa {
	void decoration();
}