public class MasalaDosa implements Dosa {
	@Override
	public void decoration() {
		System.out.println("Decorated with Masala Curry");
	}
}