import java.util.*;

public class Main {
	public static void main(String[] args) {
		int quantity;
		String type;
		ArrayList<Dosa> order = new ArrayList<Dosa>();

		Scanner sc = new Scanner(System.in);

		quantity = sc.nextInt();
		type = sc.next();

		
	}
}